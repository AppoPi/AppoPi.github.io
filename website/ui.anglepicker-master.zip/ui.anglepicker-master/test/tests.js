
module("Initialization");

test("ui.anglepicker initialization", function() {

  ok( 1 == "1", "Passed!" );
  ok( $.fn.anglepicker !== undefined, "anglepicker has been defined" );

});
